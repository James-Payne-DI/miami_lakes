#!/usr/bin/python3
# -*- coding: utf-8 -*-
import requests, time, json, jsonFunctions, base64, pprint, Live_Urls, scrape, sqlite3
from addMeta import addPageMeta

#TODO: Make this work for blogs. It should basically function the same but you'll need to scrape
#      date-of-publish, categrory, & tags

#createBackendURL - creates and returns the url of the backend of a page
def createBackendURL(dev_site, postID):
    backend_page_url = dev_site + 'wp/wp-admin/post.php?post='+ str(postID) +'&action=edit'
    return backend_page_url

#establishes the connection to the database within the variable db
db = sqlite3.connect("metaHousing.sqlite")
#Creates the table metaData if one does not already exist
db.execute("CREATE TABLE IF NOT EXISTS metaData (pageID INTEGER, pageTitle TEXT, slug TEXT, meta TEXT)")

#devsite we are migrating the content to
devsite = 'http://contentdevsandbox.dev.dealerinspire.com/'
#the id for the google sheet we get the list of links from
live_urls = Live_Urls.urlsToMigrate('1L2gDfkfpoubgKtlcMVn5d0R9PpXR54kQztDWy2O7Ov4')

#live_blogs = Live_Urls.urlsToMigrate('1nayRdiuQUQcvHK5LYA_CoEYpNPuHKdS2ybhdmY_cxS0')
#'19fSBX26VrTMT5u9n34t0PWrT1Bnx-nYPckTpd3M1LtY')
#blog1

for url in live_urls:
    scrape.livePage(url, 'content1', devsite, db)
    time.sleep(2)
    db.commit()

db.close()
print("-"*40)
print("Meta Loop")
print("-"*40)
db = sqlite3.connect("metaHousing.sqlite")
for page_id, name, slug, meta in db.execute("SELECT * FROM metaData"):
    #1.) Create the backend URL with the ID and the dev site
    backend_url = createBackendURL(devsite, page_id)
    #print(backend_url)

    #2.) use method from addMeta with backend_url & meta as parameters
    addPageMeta(backend_url,meta)

    #3.) all the meta should get  added it with the above command it exists  so when the loop closes the db link will close too

db.close()
