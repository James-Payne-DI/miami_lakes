Okay Howdy ya'll this here is Jimbos Robot, Imagine me as that paperclip that used to pop up on desktops to help users, but with a cowboy hat!

**********Purpose of program**********
miami_lakes is a command line tool that can help migrate the content of a large number of pages onto one of the DI Dev sites.

With specific commands that will be listed later in this file, the user can migrate, and store content from a large number of links all at once.
Most of the content is added via REST api but the Yoast Meta info cannot be added that way.  That's where Selenium comes in...


----Program Flow:
- during each iteration, we get the page ID within the "page" Method and return that as the value
- which we then add to the metaData table in metaHousing.sqlite (which was created when we run main.py)


----Prerequisites:















**********NOTES FOR EXPANSION**************
#TODO: Change Yoast Meta https://developer.yoast.com/blog/yoast-seo-rest-api-endpoint/
#       1. Scrape meta
#       2. getPostID of page
#       3. send edits to rest endpoint

#TODO: Make this work for blogs. It should basically function the same but you'll need to scrape
#      date-of-publish, categrory, & tags
